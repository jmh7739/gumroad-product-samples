Synthetic project handoff
